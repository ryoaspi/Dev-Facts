using System;
using UnityEngine;
using TheFundation.Runtime;

public class GameBootstrap : MonoBehaviour
{
    #region Unity API

    private void Awake()
    {
        TheFundationCore.Initialize();
    }

    private void Update()
    {
        FactAutoSaveService.Tick(Time.deltaTime);
    }

    #endregion
}