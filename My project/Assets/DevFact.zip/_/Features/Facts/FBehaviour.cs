using UnityEngine;

namespace TheFundation.Runtime
{
    public class FBehaviour : MonoBehaviour
    {
        #region Services (V2-first)

        protected static FactDictionaryV2 FactsV2 => FactDictionaryV2;

        // Pas de propriétés typées "static class" -> helpers à la place
        protected void SetFact<T>(string key, T value, FactDictionaryV2.FactPersistence p = FactDictionaryV2.FactPersistence.Runtime)
            => FactDictionaryV2.Set(key, value, p);

        protected T GetFact<T>(string key, T defaultValue = default)
            => FactDictionaryV2.TryGet(key, out T v) ? v : defaultValue;

        #endregion

        #region Save / Load

        protected void SaveFactsV2() => FactSaveSystemV2.SaveToFile();

        protected void LoadFactsV2() => FactSaveSystemV2.LoadFromFile();

        #endregion

        #region Input / Platform / Settings short helpers

        protected string GetPlayerScheme(int playerIndex, string fallback = "KeyboardMouse")
            => GetFact($"p{playerIndex}_inputScheme", fallback);

        protected string GetPlatformFamily(string fallback = "Desktop")
            => GetFact("platform_family", fallback);

        protected void SetMasterVolume(float v)
            => SettingsService.MasterVolume = v;

        protected float GetMasterVolume(float fallback = 1f)
            => SettingsService.MasterVolume; // service static direct

        #endregion
    }
}