using UnityEngine;

namespace TheFundation.Runtime
{
    public static class TheFundationCore
    {
        public static bool IsInitialized { get; private set; }

        public static void Initialize()
        {
            if (IsInitialized) return;
            IsInitialized = true;

#if UNITY_EDITOR
            Debug.Log("[TheFundation] Core init...");
#endif
            // Facts V2
            FactDictionaryV2.Initialize();
            FactSaveSystemV2.LoadFromFile();

            // Services
            LocalizationManager.Initialize();     // si ton manager a bien Initialize()
            InputSchemeService.Initialize();      // ton service input runtime
            PlatformizerService.Initialize();
            SettingsService.Initialize();

            // Autosave V2
            FactAutoSaveService.Initialize();

#if UNITY_EDITOR
            Debug.Log("[TheFundation] Core ready.");
#endif
        }
    }
}