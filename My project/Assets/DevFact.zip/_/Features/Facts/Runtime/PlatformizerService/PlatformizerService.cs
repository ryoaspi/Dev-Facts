using UnityEngine;
using UnityEngine.InputSystem;

namespace TheFundation.Runtime
{
    public static class PlatformizerService
    {
        public static bool IsInitialized { get; private set; }

        public static void Initialize()
        {
            if (IsInitialized) return;
            IsInitialized = true;

            DetectPlatformFamily();
            DetectOperatingSystem();
            DetectInputCapabilities();
        }

        private static void DetectPlatformFamily()
        {
            string family =
                Application.platform == RuntimePlatform.WebGLPlayer ? "Web" :
                SystemInfo.deviceType == DeviceType.Handheld ? "Mobile" :
                "Desktop";

            FactDictionaryV2.Set("platform_family", family, FactDictionaryV2.FactPersistence.Persistent);
        }

        private static void DetectOperatingSystem()
        {
            string os = SystemInfo.operatingSystem.ToLower();

            string cleanOS =
                os.Contains("windows") ? "Windows" :
                (os.Contains("mac") || os.Contains("osx")) ? "macOS" :
                os.Contains("linux") ? "Linux" :
                os.Contains("android") ? "Android" :
                os.Contains("ios") ? "iOS" :
                "Unknown";

            FactDictionaryV2.Set("platform_os", cleanOS, FactDictionaryV2.FactPersistence.Persistent);
        }

        private static void DetectInputCapabilities()
        {
            bool hasKeyboard = Keyboard.current != null;
            bool hasMouse    = Mouse.current != null;
            bool hasTouch    = Touchscreen.current != null || Input.touchSupported;
            bool hasGamepad  = Gamepad.all.Count > 0;

            FactDictionaryV2.Set("has_keyboard", hasKeyboard);
            FactDictionaryV2.Set("has_mouse", hasMouse);
            FactDictionaryV2.Set("has_touch", hasTouch);
            FactDictionaryV2.Set("has_gamepad", hasGamepad);
        }
    }
}