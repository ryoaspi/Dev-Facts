namespace TheFundation.Runtime
{
    public static class SettingKeys
    {
        public const string MasterVolume = "settings_masterVolume";
        public const string MusicVolume  = "settings_musicVolume";
        public const string SfxVolume    = "settings_sfxVolume";
        public const string Brightness   = "settings_brightness";
        public const string UIScale      = "settings_uiScale";
        public const string Sensitivity  = "settings_sensitivity";
    }
}