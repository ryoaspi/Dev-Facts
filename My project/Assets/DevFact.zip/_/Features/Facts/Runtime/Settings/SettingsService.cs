using UnityEngine;

namespace TheFundation.Runtime
{
    /// <summary>
    /// SettingsService
    /// ----------------
    /// Service global (non-MonoBehaviour).
    /// Gère les paramètres du joueur basés sur les Facts V2 :
    /// - Volume
    /// - Musique
    /// - Effets
    /// - Luminosité
    /// - Sensibilité
    /// - Taille UI
    /// 
    /// Ces valeurs sont persistantes et automatiquement restaurées
    /// au démarrage par TheFundationCore.
    /// </summary>
    public static class SettingsService
    {
        #region Publics

        public static bool IsInitialized { get; private set; }

        #endregion


        #region Initialization

        public static void Initialize()
        {
            if (IsInitialized) return;
            IsInitialized = true;

            LoadSettings();
            ApplyAllSettings();

#if UNITY_EDITOR
            Debug.Log("[SettingsService] Initialisé.");
#endif
        }

        #endregion


        #region Main Getters / Setters

        public static float MasterVolume
        {
            get => GetFloat(SettingKeys.MasterVolume, 1f);
            set
            {
                float val = Mathf.Clamp01(value);
                Set(SettingKeys.MasterVolume, val);
                ApplyMasterVolume(val);
            }
        }

        public static float MusicVolume
        {
            get => GetFloat(SettingKeys.MusicVolume, 1f);
            set
            {
                float val = Mathf.Clamp01(value);
                Set(SettingKeys.MusicVolume, val);
            }
        }

        public static float SfxVolume
        {
            get => GetFloat(SettingKeys.SfxVolume, 1f);
            set
            {
                float val = Mathf.Clamp01(value);
                Set(SettingKeys.SfxVolume, val);
            }
        }

        public static float Brightness
        {
            get => GetFloat(SettingKeys.Brightness, 1f);
            set => Set(SettingKeys.Brightness, Mathf.Clamp01(value));
        }

        public static float UIScale
        {
            get => GetFloat(SettingKeys.UIScale, 1f);
            set => Set(SettingKeys.UIScale, Mathf.Clamp(value, 0.5f, 2f));
        }

        public static float Sensitivity
        {
            get => GetFloat(SettingKeys.Sensitivity, 1f);
            set => Set(SettingKeys.Sensitivity, Mathf.Clamp(value, 0.1f, 10f));
        }

        #endregion


        #region Utils (Internal)

        private static float GetFloat(string key, float defaultValue)
        {
            if (FactDictionaryV2.TryGet(key, out float value))
                return value;

            return defaultValue;
        }

        private static void Set(string key, float value)
        {
            FactDictionaryV2.Set(key, value, FactDictionaryV2.FactPersistence.Persistent);
        }

        #endregion


        #region Application

        /// <summary>
        /// Applique TOUS les paramètres au système.
        /// </summary>
        private static void ApplyAllSettings()
        {
            ApplyMasterVolume(MasterVolume);
            // Future: ApplyMusicVolume, ApplyBrightness, etc.
        }

        /// <summary>
        /// Applique le volume global Unity.
        /// </summary>
        private static void ApplyMasterVolume(float value)
        {
            AudioListener.volume = value;
        }

        #endregion


        #region Load / Save

        /// <summary>
        /// Récupère les paramètres depuis les Facts persistants.
        /// </summary>
        private static void LoadSettings()
        {
            // Rien à faire : FactDictionaryV2 a déjà chargé
            // les valeurs via le FactSaveSystem.
        }

        #endregion
    }
}
