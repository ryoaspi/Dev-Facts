using System;

namespace TheFundation.Runtime
{
    /// <summary>
    /// Conteneur interne pour un Fact.
    /// Gère la valeur, la persistance, et le type d'origine.
    /// </summary>
    [Serializable]
    public class FactEntry
    {
        public object Value;
        public FactDictionaryV2.FactPersistence Persistence;
        public Type OriginalType;

        public FactEntry(object value, FactDictionaryV2.FactPersistence persistence)
        {
            Value = value;
            Persistence = persistence;
            OriginalType = value?.GetType() ?? typeof(object);
        }
    }
}