using System;
using System.Collections.Generic;

namespace TheFundation.Runtime
{
    /// <summary>
    /// FactDictionaryV2 (static store)
    /// - Set / TryGet typé
    /// - Persistence Runtime vs Persistent
    /// - OnFactChanged via FactEvents
    /// - ExportPersistent pour save
    /// </summary>
    public static class FactDictionaryV2
    {
        #region Public Types

        public enum FactPersistence
        {
            Runtime,
            Persistent
        }

        #endregion

        #region Private

        private static readonly Dictionary<string, FactEntry> _facts = new();

        #endregion

        #region Init

        public static void Initialize()
        {
            // pour l’instant rien, mais garde la porte ouverte
            // (migrations, defaults, etc.)
        }

        #endregion

        #region Public API

        public static void Set<T>(string key, T value, FactPersistence persistence = FactPersistence.Runtime)
        {
            if (string.IsNullOrEmpty(key))
                return;

            if (_facts.TryGetValue(key, out var entry))
            {
                if (Equals(entry.Value, value))
                    return;

                entry.Value = value;
                entry.Persistence = persistence;
                entry.TypeName = value?.GetType().AssemblyQualifiedName ?? "null";
            }
            else
            {
                _facts[key] = new FactEntry(value, persistence);
            }

            FactEvents.Raise(key, value);
        }

        public static bool TryGet<T>(string key, out T value)
        {
            if (_facts.TryGetValue(key, out var entry) && entry.Value is T cast)
            {
                value = cast;
                return true;
            }

            value = default;
            return false;
        }

        public static object GetRaw(string key)
            => _facts.TryGetValue(key, out var e) ? e.Value : null;

        public static bool Contains(string key) => _facts.ContainsKey(key);

        public static void Remove(string key)
        {
            if (_facts.Remove(key))
                FactEvents.Raise(key, null);
        }

        public static void RemoveByPrefix(string prefix)
        {
            var toRemove = new List<string>();
            foreach (var kvp in _facts)
                if (kvp.Key.StartsWith(prefix))
                    toRemove.Add(kvp.Key);

            foreach (var k in toRemove)
                Remove(k);
        }

        public static void ResetAll(FactPersistence persistence)
        {
            var toRemove = new List<string>();
            foreach (var kvp in _facts)
                if (kvp.Value.Persistence == persistence)
                    toRemove.Add(kvp.Key);

            foreach (var k in toRemove)
                Remove(k);
        }

        public static Dictionary<string, object> ExportPersistent()
        {
            var data = new Dictionary<string, object>();
            foreach (var kvp in _facts)
                if (kvp.Value.Persistence == FactPersistence.Persistent)
                    data[kvp.Key] = kvp.Value.Value;

            return data;
        }

        #endregion
    }
}
