using System;

namespace TheFundation.Runtime
{
    /// <summary>
    /// Événements globaux des Facts.
    /// </summary>
    public static class FactEvents
    {
        /// <summary>
        /// Appelé quand un Fact change.
        /// Params : (clé, nouvelle valeur).
        /// <summary>
    public static event Action<string, object> OnFactChanged;

    internal static void InvokeFactChanged(string key, object value)
    {
        OnFactChanged?.Invoke(key, value);
    }
}
}