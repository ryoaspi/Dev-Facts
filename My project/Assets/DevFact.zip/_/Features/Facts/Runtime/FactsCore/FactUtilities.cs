using System.Collections.Generic;

namespace TheFundation.Runtime
{
    /// <summary>Outils V2 (merge, validation simple).</summary>
    public static class FactUtilities
    {
        public static void MergeInto(Dictionary<string, object> jsonData, bool overwrite)
        {
            foreach (var kvp in jsonData)
            {
                if (!overwrite && FactDictionaryV2.Contains(kvp.Key))
                    continue;

                FactDictionaryV2.Set(kvp.Key, kvp.Value);
            }
        }
    }
}