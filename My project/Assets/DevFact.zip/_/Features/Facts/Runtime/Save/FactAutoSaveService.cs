using System;
using UnityEngine;
using System.Collections.Generic;

namespace TheFundation.Runtime
{
    /// <summary>
    /// FactAutoSaveService
    /// --------------------
    /// Service statique responsable :
    /// - d'écouter OnFactChanged
    /// - de déclencher une autosave différée (debounce)
    /// - de ne pas surcharger le disque
    /// - de sauvegarder uniquement les Facts persistants
    ///
    /// Aucun MonoBehaviour.
    /// Initialisé automatiquement par TheFundationCore.
    /// </summary>
    public static class FactAutoSaveService
    {
        #region Publics

        /// <summary>
        /// Temps en secondes avant d'effectuer la sauvegarde après la dernière modification.
        /// Valeur recommandée : 2 à 5 secondes.
        /// </summary>
        public static float m_SaveDelay = 3f;

        /// <summary>
        /// Active/désactive le log interne.
        /// </summary>
        public static bool m_DebugLog = false;

        #endregion


        #region Private

        private static bool _isInitialized = false;
        private static float _lastChangeTime = -1f;
        private static bool _pendingSave = false;

        // Pour simulation du temps sans MonoBehaviour
        private static Action<float> _updateHook;

        #endregion


        #region Initialization

        /// <summary>
        /// Appelé automatiquement par TheFundationCore.Initialize()
        /// </summary>
        public static void Initialize(Action<float> updateHook = null)
        {
            if (_isInitialized)
                return;

            _isInitialized = true;

            // Hook du temps (fourni depuis GameBootstrap ou un runner simple)
            _updateHook = updateHook;

            // Écoute les modifications de Facts V2
            FactEvents.OnFactChanged += HandleFactChanged;

#if UNITY_EDITOR
            if (m_DebugLog)
                Debug.Log("[FactAutoSaveService] Initialisé.");
#endif
        }

        #endregion


        #region Utils

        private static void HandleFactChanged(string key, object value)
        {
            // Marque une sauvegarde planifiée
            _pendingSave = true;
            _lastChangeTime = Time.realtimeSinceStartup;

            if (m_DebugLog)
                Debug.Log($"[FactAutoSave] Modification détectée → save différée dans {m_SaveDelay}s");
        }

        #endregion


        #region Main Methods

        /// <summary>
        /// Cette méthode doit être appelée régulièrement (par ex: depuis GameBootstrap.Update)
        /// ou depuis un runner dédié si tu veux.
        /// 
        /// Comme ton framework n'utilise plus de MonoBehaviour interne,
        /// le jeu doit juste appeler :
        ///     FactAutoSaveService.Tick(Time.deltaTime);
        /// </summary>
        public static void Tick(float deltaTime)
        {
            if (!_pendingSave)
                return;

            float now = Time.realtimeSinceStartup;
            float elapsed = now - _lastChangeTime;

            if (elapsed >= m_SaveDelay)
            {
                ExecuteSave();
                _pendingSave = false;
            }
        }

        private static void ExecuteSave()
        {
            if (m_DebugLog)
                Debug.Log("[FactAutoSave] Autosave exécutée.");

            // On ne sauvegarde QUE les Facts persistants
            var json = FactDictionaryV2.ExportPersistent();

            FactSaveSystem.SaveJsonRoot(json);
        }

        #endregion
    }
}
