using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace TheFundation.Runtime
{
    /// <summary>
    /// Save/Load V2 simple pour bool/int/float/string.
    /// (Suffisant pour Settings, Platform, Input, etc.)
    /// </summary>
    public static class FactSaveSystemV2
    {
        private const string FILE_NAME = "facts_v2.json";

        [Serializable]
        private class FactRecord
        {
            public string key;
            public string type;
            public string value;
        }

        [Serializable]
        private class FactFile
        {
            public List<FactRecord> records = new();
        }

        public static void SaveToFile()
        {
            var dict = FactDictionaryV2.ExportPersistent();
            var file = new FactFile();

            foreach (var kvp in dict)
            {
                var rec = new FactRecord();
                rec.key = kvp.Key;

                if (kvp.Value == null)
                {
                    rec.type = "null";
                    rec.value = "";
                }
                else if (kvp.Value is bool b)
                {
                    rec.type = "bool";
                    rec.value = b.ToString();
                }
                else if (kvp.Value is int i)
                {
                    rec.type = "int";
                    rec.value = i.ToString();
                }
                else if (kvp.Value is float f)
                {
                    rec.type = "float";
                    rec.value = f.ToString(System.Globalization.CultureInfo.InvariantCulture);
                }
                else
                {
                    rec.type = "string";
                    rec.value = kvp.Value.ToString();
                }

                file.records.Add(rec);
            }

            string json = JsonUtility.ToJson(file, true);
            string path = Path.Combine(Application.persistentDataPath, FILE_NAME);
            File.WriteAllText(path, json);
        }

        public static void LoadFromFile()
        {
            string path = Path.Combine(Application.persistentDataPath, FILE_NAME);
            if (!File.Exists(path))
                return;

            string json = File.ReadAllText(path);
            var file = JsonUtility.FromJson<FactFile>(json);
            if (file?.records == null) return;

            var data = new Dictionary<string, object>();

            foreach (var r in file.records)
            {
                object val = r.type switch
                {
                    "bool"  => bool.TryParse(r.value, out var b) ? b : false,
                    "int"   => int.TryParse(r.value, out var i) ? i : 0,
                    "float" => float.TryParse(r.value, System.Globalization.NumberStyles.Any,
                                              System.Globalization.CultureInfo.InvariantCulture, out var f) ? f : 0f,
                    "null"  => null,
                    _       => r.value
                };

                data[r.key] = val;
            }

            FactUtilities.MergeInto(data, overwrite: true);
        }
    }
}
