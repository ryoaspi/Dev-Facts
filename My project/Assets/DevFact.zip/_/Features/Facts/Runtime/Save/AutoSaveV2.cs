using UnityEngine;

namespace TheFundation.Runtime
{
    /// <summary>Autosave différée basée sur FactEvents.</summary>
    public static class FactAutoSaveService
    {
        public static float m_SaveDelay = 3f;
        public static bool m_DebugLog = false;

        private static bool _initialized;
        private static float _lastChangeTime;
        private static bool _pending;

        public static void Initialize()
        {
            if (_initialized) return;
            _initialized = true;

            FactEvents.OnFactChanged += OnFactChanged;
        }

        private static void OnFactChanged(string key, object value)
        {
            _pending = true;
            _lastChangeTime = Time.realtimeSinceStartup;
            if (m_DebugLog) Debug.Log("[FactAutoSave] Change -> pending save");
        }

        public static void Tick()
        {
            if (!_pending) return;

            float elapsed = Time.realtimeSinceStartup - _lastChangeTime;
            if (elapsed >= m_SaveDelay)
            {
                FactSaveSystemV2.SaveToFile();
                _pending = false;
                if (m_DebugLog) Debug.Log("[FactAutoSave] Saved");
            }
        }
    }
}